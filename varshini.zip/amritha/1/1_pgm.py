import os
import re

script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, './input_file.txt')
csvContent=''
with open(file_path,'r') as f:
    contents = f.read()
    contentAsArray = re.split('(?<=\\d)(?=\\D)|(?<=\\D)(?=\\d)',contents)
    print(contentAsArray)
    count = 1
    newStr=''
    for x in contentAsArray:
        # print(x)
        if count % 6 == 0:
            newStr = newStr+x+'\n'
        else:
            if x=='.':
                newStr = newStr+x
            else:
                newStr = newStr+x+','
        count = count+1   
    csvContent = newStr.replace(",.", ".")
print(csvContent)
f = open('csvfile.csv','w')   
f.write(csvContent)
f.close()   