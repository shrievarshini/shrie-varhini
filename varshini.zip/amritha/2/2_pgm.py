import os

script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, './Q2-Dataset.csv')
modifiedContent=''
with open(file_path,'r') as f:
    fileContent = f.read()
    text = ''.join([i for i in fileContent]) 
    text = text.replace("Nan", "0") 
    text = text.replace("NA", "0") 
    text = text.replace("-", "0") 
    modifiedContent = text.replace("Nil", "0")
x = open("output.csv","w")
# all the replaced text is written in the output.csv file
x.writelines(modifiedContent)
x.close()