import os
import re

script_dir = os.path.dirname(__file__)
file_path = os.path.join(script_dir, './about.txt')

with open(file_path,'r') as f:
    fileContent = f.read()
    sixLetterWords = (re.findall(r"\b\w{6,}\b", fileContent))
    print('Words with more than 6 letters : ')
    print(sixLetterWords)
    print('\n')

    counts = dict()
    words = fileContent.split()
    for word in words:
        if word in counts:
            counts[word] += 1
        else:
            counts[word] = 1
    counts_x = sorted(counts.items(), key=lambda kv: kv[1])
    print('Most occurred word and number of times occurred : ')
    print(counts_x[-1])